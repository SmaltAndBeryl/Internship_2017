package com.springservice.dao;

import java.io.Reader;
import java.io.StringReader;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.logging.impl.AvalonLogger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.springservice.utility.DBUtility;

public class LoginService {

	private Connection connection;
	
	public LoginService() {
		connection = DBUtility.getConnection();
	}

	//Method to store user credentials in DB
	
}


