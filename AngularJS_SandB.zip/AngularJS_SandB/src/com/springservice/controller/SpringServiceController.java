package com.springservice.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.springservice.dao.LoginService;
import com.springservice.domain.Login;


@RestController
@RequestMapping("/user/")
public class SpringServiceController {

	private static final String String = null;
	LoginService loginService = new LoginService();
	
	@RequestMapping(value = "/login", method = RequestMethod.POST, headers = "Accept=application/json")
	public @ResponseBody
	int LoginDetails(@RequestBody String userData) throws SQLException {
		System.out.println("Inside SpringServiceController");
		System.out.println("User Data:"+userData);
		//int userId = loginService.setuserInfo(userData);
		return 1;
	}
	
}