var loginMgmtApp = angular.module("loginMgmtApp", ['ngModal','ui.grid','ui.grid.pagination','ui.grid.autoResize', 'ngSanitize', 'ngMessages']);
											   
loginMgmtApp.controller("LoginMgmtController", function($scope,$http,$location,$timeout){
	
	$scope.login = function() {
		console.log("Name:"+$scope.userName);
		console.log("Password:"+$scope.userPwd);
		var CreateUser = {
							 Name: $scope.userName,
							 Password : $scope.userPwd
					 };
	    $http.post("http://localhost:8080/AngularJS_SandB/service/user/login",CreateUser)
							  .then(
										function(results) {
											console.log("console success");
											// Success
											console.log("Success: "+ results.status);

											//$scope.credentials = results.data;
											//console.log("Name : " + $scope.credentials);
											
										},
										function(results) {
											// error
											console.log("console error ");
											console.log("Error: "+ JSON.stringify(results) + "; "+ results.status);
											console.log("console error END ");
										}
									);
	    var gridDiv = document.querySelector('#myGrid');

        var gridOptions = {
            columnDefs: [
                {headerName: 'Name', field: 'name'},
                {headerName: 'Role', field: 'role'}
            ],
            rowData: [
                {name: 'Niall', role: 'Developer'},
                {name: 'Eamon', role: 'Manager'},
                {name: 'Brian', role: 'Musician'},
                {name: 'Kevin', role: 'Manager'}
            ]
        };

        new agGrid.Grid(gridDiv, gridOptions);
		
	};

});
