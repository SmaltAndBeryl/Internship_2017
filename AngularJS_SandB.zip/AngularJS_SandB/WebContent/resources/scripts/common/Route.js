app.config(function($routeProvider, $httpProvider) {
	$routeProvider.
	when('/',{
		templateUrl: 'resources/views/Login.html',
		controller: 'LoginMgmtController'
	}).
	otherwise({
		redirectTo: '/'
	});
});
