var app = angular.module('mainApp', [
                                 'ngRoute',
                                     'ui.bootstrap',
                                     'angular-cache',
                                     'loginMgmtApp'                                                                       
                                 ]);