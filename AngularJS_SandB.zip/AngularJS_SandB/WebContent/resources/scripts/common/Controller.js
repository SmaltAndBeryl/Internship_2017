app.controller("commonPropertiesCtrl", function($rootScope, $scope){	
	$rootScope.title = "SCGJ Login Management";	
});

